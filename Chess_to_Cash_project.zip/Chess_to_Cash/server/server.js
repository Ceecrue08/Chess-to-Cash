const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const Chess = require('chess.js');

const app = express();
app.get('/', (_req, res) => res.send('Chess to Cash server is running.'));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const rooms = new Map();
const code = () => Math.random().toString(36).slice(2, 8).toUpperCase();

io.on('connection', socket => {
  socket.on('createRoom', () => {
    let id = code();
    while (rooms.has(id)) id = code();
    const room = { game: new Chess(), players: { w: socket.id, b: null } };
    rooms.set(id, room);
    socket.join(id); socket.data.room = id; socket.data.color = 'w';
    socket.emit('roomCreated', { room: id, color: 'w', fen: room.game.fen() });
  });

  socket.on('joinRoom', ({ room: raw } = {}) => {
    const id = String(raw || '').trim().toUpperCase();
    const room = rooms.get(id);
    if (!room) return socket.emit('errorMessage', 'Room not found. Check the code.');
    if (room.players.b) return socket.emit('errorMessage', 'This room already has two players.');
    room.players.b = socket.id;
    socket.join(id); socket.data.room = id; socket.data.color = 'b';
    socket.emit('joined', { room: id, color: 'b', fen: room.game.fen() });
    socket.to(id).emit('opponentJoined');
  });

  socket.on('move', payload => {
    const id = payload && payload.room;
    const room = rooms.get(id);
    if (!room || socket.data.room !== id) return;
    const color = socket.data.color;
    if (room.game.turn() !== color) return socket.emit('errorMessage', 'It is not your turn.');
    const hist = Array.isArray(payload.history) ? payload.history : [];
    const candidate = new Chess();
    try { for (const san of hist) { if (!candidate.move(san)) throw new Error('illegal'); } }
    catch (_) { return socket.emit('errorMessage', 'Illegal move rejected.'); }
    if (candidate.fen() !== payload.fen) return socket.emit('errorMessage', 'Board state did not validate.');
    room.game = candidate;
    io.to(id).emit('state', { fen: room.game.fen(), history: room.game.history() });
  });

  socket.on('disconnect', () => {
    const id = socket.data.room;
    if (id) {
      socket.to(id).emit('opponentLeft');
      const r = rooms.get(id);
      if (r && (r.players.w === socket.id || r.players.b === socket.id)) {
        // Keep the room briefly so a temporary reconnect does not immediately erase it.
        if (!r.players.w || r.players.w === socket.id) r.players.w = null;
        if (!r.players.b || r.players.b === socket.id) r.players.b = null;
        if (!r.players.w && !r.players.b) rooms.delete(id);
      }
    }
  });
});
const port = process.env.PORT || 3000;
server.listen(port, () => console.log(`Chess to Cash server listening on ${port}`));
