# Chess to Cash — Android project (starter)

A minimal Android WebView wrapper around a responsive chess UI, with a room-based online multiplayer server.

## What is included

- Android app project (`app/`) named **Chess to Cash**
- Responsive modern board UI
- Legal move generation, check/checkmate, castling, en passant, promotion and draw detection via `chess.js`
- Local two-player mode
- Casual computer opponent with a small minimax search (not tournament-strength)
- Online rooms using Socket.IO (one room creator as White, one joiner as Black)
- No real-money wagering, deposits, or prizes

## Important: online play needs a deployed server

The Android app cannot connect to other players by itself. You must deploy `server/` to a public Node.js host that supports WebSockets, then enter its HTTPS URL in the app. The app is not preconfigured with a server URL and online play will not work until you deploy one.

### Deploy the server locally for testing

Install Node.js 18 or newer, then:

```bash
cd server
npm install
npm start
```

This starts port 3000. For testing on the same Wi-Fi, use your computer's LAN IP and `http://YOUR-LAN-IP:3000` in the app. For play over the internet, deploy it to a host that supports Node.js/WebSockets and use the host's HTTPS URL. Configure a firewall and rate limits before public use.

### Build the Android APK

1. Install Android Studio on a computer.
2. Extract this folder and open `Chess_to_Cash/` as an existing Gradle project.
3. Let Android Studio install the required Android Gradle Plugin / SDK components (compile SDK 35).
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer it to your Android phone and install it. You may need to allow installation from that file manager.

Alternative command line (with JDK 17 and Android SDK configured):

```bash
./gradlew assembleDebug
```

The Gradle wrapper JAR is not bundled in this starter ZIP. If you do not have a wrapper, open in Android Studio and let it configure Gradle, or run `gradle assembleDebug` with a compatible Gradle installation.

## Configure online play

1. Deploy the `server/` folder.
2. Open the app, paste the deployed server URL (for example `https://your-service.example`).
3. Tap **Create room**, then share the displayed room code.
4. Your opponent enters the same server URL and room code, then taps **Join room**.

## Dependencies and network

The web UI loads `chess.js` and Socket.IO browser client from public CDNs at runtime. An internet connection is required for these scripts and for online play. For a production release, vendor the JavaScript files locally, use HTTPS only, and configure a restrictive Socket.IO CORS policy.

## Scope / limitations

- This is a runnable starter project, not a production-ready competitive chess service.
- Online rooms are in-memory; games disappear when the server restarts. No account system, matchmaking, chat, ratings, or persistent history.
- A disconnect currently frees that player's seat; reconnection/resume is not implemented.
- The server validates the complete move history against `chess.js`, but should still receive security review and rate limiting before public deployment.
- The computer's Normal setting is casual. It is not a chess engine like Stockfish.


## Prototype additions (October 2026)

- Added a wallet / coin-shop preview using demo-only coins. The 10 coins = Rp1,000 figure is displayed as a proposed price only; no payment is collected.
- Added marketplace offer cards and local video-duration validation for a dispute-evidence preview (10 seconds maximum). No order, escrow, P2P transfer, video upload, payout, or dispute submission is processed.
- Real QRIS and Google Play Billing require provider integration and server-side purchase verification. A paid entry-fee pot that pays a winner also requires legal and platform-policy review; this prototype deliberately does not implement paid staking, cash prizes, or cash-out.

## Build status

This is source code, not a compiled APK. Build it with Android Studio and Android SDK installed. The current build environment did not have Android SDK / Gradle configured, so an APK was not built or verified here.
